const people = [
  { name: "John", surname: "Doe", age: 25, gender: "male" },
  { name: "Jane", surname: "Smith", age: 30, gender: "female" },
  { name: "Alice", surname: "Johnson", age: 22, gender: "female" },
  { name: "Bob", surname: "Brown", age: 28, gender: "male" },
  { name: "Charlie", surname: "Davis", age: 35, gender: "male" },
  { name: "Emily", surname: "Wilson", age: 27, gender: "female" },
  { name: "David", surname: "Garcia", age: 40, gender: "male" },
  { name: "Sophia", surname: "Martinez", age: 19, gender: "female" },
  { name: "Michael", surname: "Rodriguez", age: 32, gender: "male" },
  { name: "Emma", surname: "Hernandez", age: 29, gender: "female" },
  { name: "Olivia", surname: "Lopez", age: 24, gender: "female" },
  { name: "Liam", surname: "Gonzalez", age: 31, gender: "male" },
  { name: "Noah", surname: "Perez", age: 26, gender: "male" },
  { name: "Mason", surname: "Sanchez", age: 23, gender: "male" },
  { name: "Isabella", surname: "Clark", age: 21, gender: "female" },
];

function addPerson(name, surname, age, gender) {
  people.push({ name, surname, age, gender });
}

function getTotalPeople() {
  return people.length;
}

function getAverageAge() {
  return people.reduce((acc, current) => acc += current.age, 0) / people.length;
}

function calculateTotalAgeByGender(gender) {
  return people.filter((person) => person.gender === gender).reduce((acc, current) => acc += current.age, 0)
}

document.forms.personForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(document.forms.personForm);
  if (formData.name == null || formData.surname == null || formData.age == null || formData.gender == null) throw new Error("Missing user data."); 
  addPerson(formData.name, formData.surname, formData.age, formData.gender);
  return false;
});

document.addEventListener("DOMContentLoaded", (event) => {
  const elements = document.querySelectorAll("form > input");
  for (const element of elements) formatValidInput(element, element.value);
});

document.forms.personForm.addEventListener("input", (event) => {
  const input = document.getElementById(event.target.id);
  formatValidInput(event.target, input.value);
});

function formatValidInput(target, input) {
  if (input.length > 0) return target.classList.add("valid");
  return target.classList.add("invalid");
}

function showTotalPeople() {
  const textElement = document.getElementById("totalPeople");
  textElement.textContent = getTotalPeople();
}

function showAverageAge() {
  const textElement = document.getElementById("averageAge");
  textElement.textContent = JSON.stringify(getAverageAge());
}

function showTotalAgeByGender() {
  const textElement = document.getElementById("totalAgeByGender");
  const genders = ["male", "female"];
  textElement.textContent = genders.map((gender) => {
    const ageByGender = calculateTotalAgeByGender(gender);
    return `${gender}: ${ageByGender}`;
  }).join(" ")
}